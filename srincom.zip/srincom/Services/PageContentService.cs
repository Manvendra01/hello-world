﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class PageContentService
    {
        IServiceFactory _serviceFactory;
        public PageContentService(IServiceFactory serviceFactory)
        {
            _serviceFactory = serviceFactory;
        }
        public object GetContentById(string id)
        {
            return _serviceFactory.GetDBService().getDataTable("EXEC srinoida_website.sn.GetCommonData @type='pageContent.byId'");
        }
    }
}
