﻿using Services.database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public interface IServiceFactory
    {
        WebService1SoapClient GetDBService();
    }
    public class ServiceFactory : IServiceFactory
    {
        public WebService1SoapClient GetDBService()
        {
            return new WebService1SoapClient();
        }
    }
}
