﻿using Ninject.Modules;
using Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace srincom.Helpers
{
    public class Injector : NinjectModule
    {
        public override void Load()
        {
            this.Bind<IServiceFactory>().To<ServiceFactory>().InTransientScope();
            this.Bind<PageContentService>().To<PageContentService>().InTransientScope();
        }
    }
}